#Kirill Dialogues-------------------------------------------------------

d_chief_kirill_1 = {
        "a": ["OPTION A", "NPC RESPONCE A", "end_convo"],
        "b": ["OPTION B", "NPC RESPONCE B", "end_convo"],
        "c": ["OPTION C", "NPC RESPONCE C", "end_convo"]
    }


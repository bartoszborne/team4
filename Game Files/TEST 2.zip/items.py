assignment = {
    "id": "Assigmnent",
    "name": "an assigmnent",
    "description": "Assigmnent, Case No. 010487"
}

victim_belongings = {
    "id": "Victim's Belongings",
    "name": "the victim's belongings",
    "description": "Victim's belongings"
}
import items
import mapstructure as map_s

inventory = [items.assignment]

# Start game at the reception
current_room = map_s.rooms["outsideoutside"]
